execute as @a[distance=..20] at @s run kill @e[type=marker,tag=circus,sort=nearest,limit=1]

