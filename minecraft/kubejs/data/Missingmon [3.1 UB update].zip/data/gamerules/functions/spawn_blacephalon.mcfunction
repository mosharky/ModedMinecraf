execute as @e[type=marker,tag=circus] at @s run pokespawn blacephalon level=70 ~ ~ ~
execute as @e[type=marker,tag=circus] at @s run tellraw @a {"text":"??? has appear!","color":"blue","bold":true}
execute as @e[type=marker,tag=circus] at @s run playsound minecraft:portal.trigger master @a[distance=..20] ~ ~ ~ 1 1 1











