clear @a[distance=..20,nbt={Inventory:[{id:"minecraft:firework_rocket"}]}] minecraft:firework_rocket
function gamerules:kill_circus_tag
