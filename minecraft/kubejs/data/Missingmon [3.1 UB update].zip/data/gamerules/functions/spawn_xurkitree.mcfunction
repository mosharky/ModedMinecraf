execute as @e[type=marker,tag=lightning] at @s run pokespawn xurkitree level=70 ~ ~ ~
execute as @e[type=marker,tag=lightning] at @s run tellraw @a {"text":"??? has appear!","color":"blue","bold":true}
execute as @e[type=marker,tag=lightning] at @s run playsound minecraft:entity.lightning_bolt.thunder master @a[distance=..5] ~ ~ ~ 10 1 1












