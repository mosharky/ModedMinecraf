execute as @e[type=marker,tag=gate] at @s run summon tnt ~ ~ ~ {Fuse:0}


