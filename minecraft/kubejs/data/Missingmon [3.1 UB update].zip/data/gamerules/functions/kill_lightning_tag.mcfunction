execute as @a[distance=..20] at @s run kill @e[type=marker,tag=lightning,sort=nearest,limit=1]

