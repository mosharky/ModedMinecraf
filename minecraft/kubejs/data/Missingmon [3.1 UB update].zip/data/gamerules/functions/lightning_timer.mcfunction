execute as @e[type=marker,tag=lightning] at @s run execute if entity @a[distance=..50] run scoreboard players add @s lightning_timer 1
execute as @e[type=marker,tag=lightning,scores={lightning_timer=200..}] at @s run function gamerules:summon_lightning
execute as @e[type=marker,tag=lightning,scores={lightning_timer=200..}] run scoreboard players set @s lightning_timer 0

