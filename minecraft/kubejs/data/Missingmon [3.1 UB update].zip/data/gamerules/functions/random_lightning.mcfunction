# Randomly summon lightning around the marker
execute at @e[type=marker, tag=lightning, distance=..50] run execute if score @s lightning_timer matches 0 run summon lightning_bolt ~ ~ ~
