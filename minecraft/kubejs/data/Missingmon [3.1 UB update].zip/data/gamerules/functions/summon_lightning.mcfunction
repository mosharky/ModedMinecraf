execute as @e[type=marker,tag=lightning2] at @s run summon lightning_bolt ~ ~ ~ 
execute as @e[type=marker,tag=lightning3] at @s run summon lightning_bolt ~ ~ ~ 



