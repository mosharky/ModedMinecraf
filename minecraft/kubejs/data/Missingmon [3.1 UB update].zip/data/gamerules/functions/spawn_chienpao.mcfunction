execute as @e[type=marker,tag=frost] at @s run pokespawn chienpao level=70 ~ ~ ~
execute as @e[type=marker,tag=frost] at @s run tellraw @a {"text":"The seal are crumbling!","color":"aqua","bold":true}
execute as @e[type=marker,tag=frost] at @s run playsound minecraft:portal.trigger master @a[distance=..20] ~ ~ ~ 1 1 1











