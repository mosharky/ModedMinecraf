execute as @e[type=marker,tag=lightning] at @s run execute if entity @a[distance=..50] run function gamerules:lightning_timer
