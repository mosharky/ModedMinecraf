execute as @a[distance=..50] at @s run kill @e[type=marker,tag=saber,sort=nearest,limit=1]
execute as @e[type=marker,tag=gate] at @s run summon tnt ~ ~ ~ {Fuse:0}


