gamerule commandBlockOutput false
scoreboard objectives add lightning_rods_destroyed minecraft.mined:minecraft.lightning_rod
scoreboard objectives add lightning_timer dummy

