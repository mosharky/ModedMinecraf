execute as @e[type=marker,tag=ilex] at @s run pokespawn celebi level=30 ~ ~ ~
execute as @e[type=marker,tag=ilex] at @s run tellraw @a {"text":"Celebi has appear!","color":"lime","bold":true}
execute as @e[type=marker,tag=ilex] at @s run playsound minecraft:portal.trigger master @a[distance=..20] ~ ~ ~ 1 1 1











